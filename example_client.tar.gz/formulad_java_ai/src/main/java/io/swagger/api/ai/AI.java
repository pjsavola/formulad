package io.swagger.api.ai;

import io.swagger.model.GameState;
import io.swagger.model.Moves;
import io.swagger.model.NameAtStart;
import io.swagger.model.SelectedIndex;
import io.swagger.model.Track;

public interface AI {
    NameAtStart startGame(Track track);
    io.swagger.model.Gear selectGear(GameState gameState);
    SelectedIndex selectMove(Moves moves);
}
