package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Node;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * A valid move a player can take containing the identifier of the node and what repercussions there will be for choosing that
 */
@ApiModel(description = "A valid move a player can take containing the identifier of the node and what repercussions there will be for choosing that")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-06-13T20:37:21.994Z")

public class ValidMove extends Node  {
  @JsonProperty("overshoot")
  private Integer overshoot = null;

  @JsonProperty("braking")
  private Integer braking = null;

  public ValidMove overshoot(Integer overshoot) {
    this.overshoot = overshoot;
    return this;
  }

  /**
   * Get overshoot
   * minimum: 0
   * @return overshoot
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0)
  public Integer getOvershoot() {
    return overshoot;
  }

  public void setOvershoot(Integer overshoot) {
    this.overshoot = overshoot;
  }

  public ValidMove braking(Integer braking) {
    this.braking = braking;
    return this;
  }

  /**
   * Get braking
   * minimum: 0
   * @return braking
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

@Min(0)
  public Integer getBraking() {
    return braking;
  }

  public void setBraking(Integer braking) {
    this.braking = braking;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    ValidMove validMove = (ValidMove) o;
    return Objects.equals(this.overshoot, validMove.overshoot) &&
        Objects.equals(this.braking, validMove.braking) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(overshoot, braking, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class ValidMove {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    overshoot: ").append(toIndentedString(overshoot)).append("\n");
    sb.append("    braking: ").append(toIndentedString(braking)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

