package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Gear;
import io.swagger.model.Node;
import io.swagger.model.PlayerId;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * State of a player: location, hit points, current gear and how many stops a player has made in the current curve
 */
@ApiModel(description = "State of a player: location, hit points, current gear and how many stops a player has made in the current curve")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-06-13T20:37:21.994Z")

public class PlayerState extends PlayerId  {
  @JsonProperty("gear")
  private Integer gear = null;

  /**
   * Gets or Sets type
   */
  public enum TypeEnum {
    START("START"),
    
    STRAIGHT("STRAIGHT"),
    
    CURVE_1("CURVE_1"),
    
    CURVE_2("CURVE_2"),
    
    CURVE_3("CURVE_3"),
    
    FINISH("FINISH");

    private String value;

    TypeEnum(String value) {
      this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
      return String.valueOf(value);
    }

    @JsonCreator
    public static TypeEnum fromValue(String text) {
      for (TypeEnum b : TypeEnum.values()) {
        if (String.valueOf(b.value).equals(text)) {
          return b;
        }
      }
      return null;
    }
  }

  @JsonProperty("type")
  private TypeEnum type = null;

  @JsonProperty("nodeId")
  private Integer nodeId = null;

  @JsonProperty("hitpoints")
  private Integer hitpoints = null;

  @JsonProperty("stops")
  private Integer stops = null;

  @JsonProperty("leeway")
  private Integer leeway = null;

  public PlayerState gear(Integer gear) {
    this.gear = gear;
    return this;
  }

  /**
   * Get gear
   * @return gear
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getGear() {
    return gear;
  }

  public void setGear(Integer gear) {
    this.gear = gear;
  }

  public PlayerState type(TypeEnum type) {
    this.type = type;
    return this;
  }

  /**
   * Get type
   * @return type
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public TypeEnum getType() {
    return type;
  }

  public void setType(TypeEnum type) {
    this.type = type;
  }

  public PlayerState nodeId(Integer nodeId) {
    this.nodeId = nodeId;
    return this;
  }

  /**
   * Get nodeId
   * @return nodeId
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getNodeId() {
    return nodeId;
  }

  public void setNodeId(Integer nodeId) {
    this.nodeId = nodeId;
  }

  public PlayerState hitpoints(Integer hitpoints) {
    this.hitpoints = hitpoints;
    return this;
  }

  /**
   * Remaining hitpoints of the player.
   * minimum: 0
   * @return hitpoints
  **/
  @ApiModelProperty(required = true, value = "Remaining hitpoints of the player.")
  @NotNull

@Min(0)
  public Integer getHitpoints() {
    return hitpoints;
  }

  public void setHitpoints(Integer hitpoints) {
    this.hitpoints = hitpoints;
  }

  public PlayerState stops(Integer stops) {
    this.stops = stops;
    return this;
  }

  /**
   * The amount of stops the player has made in the current curve or zero.
   * minimum: 0
   * @return stops
  **/
  @ApiModelProperty(required = true, value = "The amount of stops the player has made in the current curve or zero.")
  @NotNull

@Min(0)
  public Integer getStops() {
    return stops;
  }

  public void setStops(Integer stops) {
    this.stops = stops;
  }

  public PlayerState leeway(Integer leeway) {
    this.leeway = leeway;
    return this;
  }

  /**
   * The number of milliseconds the player can miss the time limits for the rest of the game.
   * minimum: 0
   * @return leeway
  **/
  @ApiModelProperty(required = true, value = "The number of milliseconds the player can miss the time limits for the rest of the game.")
  @NotNull

@Min(0)
  public Integer getLeeway() {
    return leeway;
  }

  public void setLeeway(Integer leeway) {
    this.leeway = leeway;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    PlayerState playerState = (PlayerState) o;
    return Objects.equals(this.gear, playerState.gear) &&
        Objects.equals(this.type, playerState.type) &&
        Objects.equals(this.nodeId, playerState.nodeId) &&
        Objects.equals(this.hitpoints, playerState.hitpoints) &&
        Objects.equals(this.stops, playerState.stops) &&
        Objects.equals(this.leeway, playerState.leeway) &&
        super.equals(o);
  }

  @Override
  public int hashCode() {
    return Objects.hash(gear, type, nodeId, hitpoints, stops, leeway, super.hashCode());
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class PlayerState {\n");
    sb.append("    ").append(toIndentedString(super.toString())).append("\n");
    sb.append("    gear: ").append(toIndentedString(gear)).append("\n");
    sb.append("    type: ").append(toIndentedString(type)).append("\n");
    sb.append("    nodeId: ").append(toIndentedString(nodeId)).append("\n");
    sb.append("    hitpoints: ").append(toIndentedString(hitpoints)).append("\n");
    sb.append("    stops: ").append(toIndentedString(stops)).append("\n");
    sb.append("    leeway: ").append(toIndentedString(leeway)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

