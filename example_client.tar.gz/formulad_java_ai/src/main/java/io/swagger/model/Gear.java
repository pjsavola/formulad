package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Gear of the car. It can be be 0 in the start but 0 can never be chosen.
 */
@ApiModel(description = "Gear of the car. It can be be 0 in the start but 0 can never be chosen.")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-06-13T20:37:21.994Z")

public class Gear   {
  @JsonProperty("gear")
  private Integer gear = null;

  public Gear gear(Integer gear) {
    this.gear = gear;
    return this;
  }

  /**
   * Get gear
   * @return gear
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull


  public Integer getGear() {
    return gear;
  }

  public void setGear(Integer gear) {
    this.gear = gear;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Gear gear = (Gear) o;
    return Objects.equals(this.gear, gear.gear);
  }

  @Override
  public int hashCode() {
    return Objects.hash(gear);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Gear {\n");
    
    sb.append("    gear: ").append(toIndentedString(gear)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

