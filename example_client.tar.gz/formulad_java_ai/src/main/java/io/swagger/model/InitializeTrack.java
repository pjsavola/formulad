package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.Edge;
import io.swagger.model.Node;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Track as a graph
 */
@ApiModel(description = "Track as a graph")
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-06-13T20:37:21.994Z")

public class InitializeTrack   {
  @JsonProperty("nodes")
  @Valid
  private List<Node> nodes = new ArrayList<Node>();

  @JsonProperty("edges")
  @Valid
  private List<Edge> edges = new ArrayList<Edge>();

  public InitializeTrack nodes(List<Node> nodes) {
    this.nodes = nodes;
    return this;
  }

  public InitializeTrack addNodesItem(Node nodesItem) {
    this.nodes.add(nodesItem);
    return this;
  }

  /**
   * Get nodes
   * @return nodes
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public List<Node> getNodes() {
    return nodes;
  }

  public void setNodes(List<Node> nodes) {
    this.nodes = nodes;
  }

  public InitializeTrack edges(List<Edge> edges) {
    this.edges = edges;
    return this;
  }

  public InitializeTrack addEdgesItem(Edge edgesItem) {
    this.edges.add(edgesItem);
    return this;
  }

  /**
   * Get edges
   * @return edges
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public List<Edge> getEdges() {
    return edges;
  }

  public void setEdges(List<Edge> edges) {
    this.edges = edges;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    InitializeTrack initializeTrack = (InitializeTrack) o;
    return Objects.equals(this.nodes, initializeTrack.nodes) &&
        Objects.equals(this.edges, initializeTrack.edges);
  }

  @Override
  public int hashCode() {
    return Objects.hash(nodes, edges);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class InitializeTrack {\n");
    
    sb.append("    nodes: ").append(toIndentedString(nodes)).append("\n");
    sb.append("    edges: ").append(toIndentedString(edges)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

