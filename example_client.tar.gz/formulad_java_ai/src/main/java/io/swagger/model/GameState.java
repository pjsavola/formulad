package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.GameId;
import io.swagger.model.PlayerState;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * GameState
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-06-13T20:37:21.994Z")

public class GameState   {
  @JsonProperty("game")
  private GameId game = null;

  @JsonProperty("players")
  @Valid
  private List<PlayerState> players = new ArrayList<PlayerState>();

  public GameState game(GameId game) {
    this.game = game;
    return this;
  }

  /**
   * Get game
   * @return game
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public GameId getGame() {
    return game;
  }

  public void setGame(GameId game) {
    this.game = game;
  }

  public GameState players(List<PlayerState> players) {
    this.players = players;
    return this;
  }

  public GameState addPlayersItem(PlayerState playersItem) {
    this.players.add(playersItem);
    return this;
  }

  /**
   * Get players
   * @return players
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public List<PlayerState> getPlayers() {
    return players;
  }

  public void setPlayers(List<PlayerState> players) {
    this.players = players;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    GameState gameState = (GameState) o;
    return Objects.equals(this.game, gameState.game) &&
        Objects.equals(this.players, gameState.players);
  }

  @Override
  public int hashCode() {
    return Objects.hash(game, players);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class GameState {\n");
    
    sb.append("    game: ").append(toIndentedString(game)).append("\n");
    sb.append("    players: ").append(toIndentedString(players)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

