package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.GameId;
import io.swagger.model.ValidMove;
import java.util.ArrayList;
import java.util.List;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Moves
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-06-13T20:37:21.994Z")

public class Moves   {
  @JsonProperty("game")
  private GameId game = null;

  @JsonProperty("moves")
  @Valid
  private List<ValidMove> moves = null;

  public Moves game(GameId game) {
    this.game = game;
    return this;
  }

  /**
   * Get game
   * @return game
  **/
  @ApiModelProperty(value = "")

  @Valid

  public GameId getGame() {
    return game;
  }

  public void setGame(GameId game) {
    this.game = game;
  }

  public Moves moves(List<ValidMove> moves) {
    this.moves = moves;
    return this;
  }

  public Moves addMovesItem(ValidMove movesItem) {
    if (this.moves == null) {
      this.moves = new ArrayList<ValidMove>();
    }
    this.moves.add(movesItem);
    return this;
  }

  /**
   * Get moves
   * @return moves
  **/
  @ApiModelProperty(value = "")

  @Valid

  public List<ValidMove> getMoves() {
    return moves;
  }

  public void setMoves(List<ValidMove> moves) {
    this.moves = moves;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Moves moves = (Moves) o;
    return Objects.equals(this.game, moves.game) &&
        Objects.equals(this.moves, moves.moves);
  }

  @Override
  public int hashCode() {
    return Objects.hash(game, moves);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Moves {\n");
    
    sb.append("    game: ").append(toIndentedString(game)).append("\n");
    sb.append("    moves: ").append(toIndentedString(moves)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

