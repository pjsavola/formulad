package io.swagger.model;

import java.util.Objects;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonCreator;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import io.swagger.model.GameId;
import io.swagger.model.InitializeTrack;
import io.swagger.model.PlayerId;
import org.springframework.validation.annotation.Validated;
import javax.validation.Valid;
import javax.validation.constraints.*;

/**
 * Track
 */
@Validated
@javax.annotation.Generated(value = "io.swagger.codegen.languages.SpringCodegen", date = "2018-06-13T20:37:21.994Z")

public class Track   {
  @JsonProperty("player")
  private PlayerId player = null;

  @JsonProperty("game")
  private GameId game = null;

  @JsonProperty("track")
  private InitializeTrack track = null;

  public Track player(PlayerId player) {
    this.player = player;
    return this;
  }

  /**
   * Get player
   * @return player
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public PlayerId getPlayer() {
    return player;
  }

  public void setPlayer(PlayerId player) {
    this.player = player;
  }

  public Track game(GameId game) {
    this.game = game;
    return this;
  }

  /**
   * Get game
   * @return game
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public GameId getGame() {
    return game;
  }

  public void setGame(GameId game) {
    this.game = game;
  }

  public Track track(InitializeTrack track) {
    this.track = track;
    return this;
  }

  /**
   * Get track
   * @return track
  **/
  @ApiModelProperty(required = true, value = "")
  @NotNull

  @Valid

  public InitializeTrack getTrack() {
    return track;
  }

  public void setTrack(InitializeTrack track) {
    this.track = track;
  }


  @Override
  public boolean equals(java.lang.Object o) {
    if (this == o) {
      return true;
    }
    if (o == null || getClass() != o.getClass()) {
      return false;
    }
    Track track = (Track) o;
    return Objects.equals(this.player, track.player) &&
        Objects.equals(this.game, track.game) &&
        Objects.equals(this.track, track.track);
  }

  @Override
  public int hashCode() {
    return Objects.hash(player, game, track);
  }

  @Override
  public String toString() {
    StringBuilder sb = new StringBuilder();
    sb.append("class Track {\n");
    
    sb.append("    player: ").append(toIndentedString(player)).append("\n");
    sb.append("    game: ").append(toIndentedString(game)).append("\n");
    sb.append("    track: ").append(toIndentedString(track)).append("\n");
    sb.append("}");
    return sb.toString();
  }

  /**
   * Convert the given object to string with each line indented by 4 spaces
   * (except the first line).
   */
  private String toIndentedString(java.lang.Object o) {
    if (o == null) {
      return "null";
    }
    return o.toString().replace("\n", "\n    ");
  }
}

